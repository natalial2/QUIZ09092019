﻿using System;

namespace QUIZ09092019
{
    class Program
    {
        static void Main(string[] args)
        {
           bangunDatar obj = new bangunDatar();

           obj.luasPersegi();

           obj.luas_segitiga();

           obj.luas_lingkaran();

           
           bangunRuang tes = new bangunRuang();

           tes.volume_balok();

           tes.volume_kubus();
        }
    }
}
